// Fastest under Heaven ... r8 (2025-Jul-26)
// Fastest under Heaven ... r7 (2025-Jul-18)
// Fastest under Heaven ... r4 (2025-May-11)
// wget http://mattmahoney.net/dc/enwik9.zip
// ./hashBBs enwik9 > results.csv

// For enwik9 (~1GB), the benchmark hashes all BBs at all positions, producing a CSV like:
// 
// Hasher,BB_Size,Total_Hashes,Unique_Hashes,Collisions,Time_s,Speed_GBs,Cycles_Byte
// Pippip,2,999999999,123456789,876543210,10.123456,0.198,8.050
// Pippip,4,999999997,234567890,765432107,10.234567,0.390,4.090
// ...
// Pippip,8192,999991809,789012345,210979464,20.345678,400.123,0.305
// Wyhash,2,999999999,123456788,876543211,5.123456,0.390,4.098
// ...
// Komihash,2,999999999,123456790,876543209,5.234567,0.382,4.194
// ...
// 
//     Total Hashes: file_size - bb_size + 1 (e.g., ~1B for BB=2, ~1B-8191 for BB=8192).
//     Unique Hashes: Number of set bits in hash table (approximated above).
//     Collisions: total_hashes - unique_hashes.
//     Time_s: Wall-clock time for hashing.
//     Speed_GBs: (total_hashes * bb_size) / (time_s * 1e9).
//     Cycles_Byte: (time_s * CLOCK_FREQ) / (total_hashes * bb_size).


/*
#include <arm_neon.h>

static inline uint8x16_t aesenc_arm(uint8x16_t state, uint8x16_t round_key) {
    // AESE: SubBytes, ShiftRows, AddRoundKey
    state = vaeseq_u8(state, round_key);
    // AESMC: MixColumns
    state = vaesmcq_u8(state);
    return state;
}
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Configuration
#define HASH_TABLE_BITS (1ULL << 32) // 2^32 entries
#define HASH_TABLE_BYTES (HASH_TABLE_BITS / 8) // 512MB bit array
#define MAX_BB_SIZE 8192

#include "meow_hash_x64_aesni.h"

#include "komihash.h"
#include "wyhash.h"
//#include "Pippip_OOO.h" //r2
//#include "Pippip_AES_TriXZi.h" //r3
#include "Pippip.h"

//#include "xxh3.h"
#define XXH_STATIC_LINKING_ONLY   /* *_state_t */
#include "xxhash.h"

XXH64_hash_t Cyan;
//XXH128_hash_t Cyan;

uint32_t hash;

// Bit array operations
static inline void set_bit(uint8_t *table, uint32_t hash) {
    uint32_t byte_idx = hash >> 3;
    uint8_t bit_idx = hash & 7;
    table[byte_idx] |= (1 << bit_idx);
}

static uint64_t count_bits(uint8_t *table, size_t size) {
    uint64_t count = 0;
    for (size_t i = 0; i < size; i++) {
        uint8_t byte = table[i];
        while (byte) {
            count += byte & 1;
            byte >>= 1;
        }
    }
    return count;
}

/*
Compute Byte Index:
        uint32_t byte_idx = hash >> 3;
        Right-shift hash by 3 (divide by 8) to find the byte in table containing the bit for hash.
        Why 8? Each uint8_t (byte) holds 8 bits, so hash / 8 gives the byte index.
        Example: For hash = 42:
            42 >> 3 = 42 / 8 = 5 → byte_idx = 5.
            The bit for hash = 42 is in table[5].
Compute Bit Index:
        uint8_t bit_idx = hash & 7;
        Bitwise AND with 7 (binary 111) extracts the lower 3 bits of hash, giving the bit position within the byte (0 to 7).
        Equivalent to hash % 8.
        Example: For hash = 42:
            42 & 7 = 42 % 8 = 2 → bit_idx = 2.
            The bit is the 2nd bit (0-based) in table[5].
Set the Bit:
        table[byte_idx] |= (1 << bit_idx);
        Left-shift 1 by bit_idx to create a mask (e.g., 1 << 2 = 00000100).
        Bitwise OR with table[byte_idx] sets the specified bit to 1, leaving other bits unchanged.
        Example: For hash = 42, byte_idx = 5, bit_idx = 2:
            If table[5] = 00000000 (initially):
                1 << 2 = 00000100.
                table[5] |= 00000100 → table[5] = 00000100.
            Marks hash = 42 as seen.

Example Walkthrough

    Hash = 42:
        byte_idx = 42 >> 3 = 5.
        bit_idx = 42 & 7 = 2.
        table[5] |= (1 << 2) sets bit 2 in table[5].
    Hash = 43:
        byte_idx = 43 >> 3 = 5.
        bit_idx = 43 & 7 = 3.
        table[5] |= (1 << 3) sets bit 3 in table[5].
        If table[5] = 00000100 (from hash = 42):
            1 << 3 = 00001000.
            table[5] |= 00001000 → table[5] = 00001100.
*/

// Bernstein's hash
uint32_t Bernstein(const char *key, size_t len) {
	uint32_t hash = 5381;
	for(uint32_t i = 0; i < len; ++i)
		hash = 33 * hash + key[i];
	return hash;// ^ (hash >> 16);
}

static uint32_t Bernstein_wrapper(const char *key, size_t len) {
    return Bernstein(key, len);
}
static uint32_t Pippip_AES_TriXZi_Mikayla_wrapper(const char *key, size_t len) {
    //return FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi(key, len); //r6
	uint32_t rslt[1];
    FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla(key, len, 0, (void *)rslt); //r7
	return rslt[0];
}
static uint32_t wyhash_wrapper(const char *key, size_t len) {
    return wyhash(key, len, 0, _wyp);
}
static uint32_t komihash_wrapper(const char *key, size_t len) {
    return komihash(key, len, 0);
}

static uint32_t XXH3_64bits_wrapper(const char *key, size_t len) {
    return XXH3_64bits_withSeed(key, len, 0);
}

static uint32_t MeowHash_wrapper(const char *key, size_t len) {
    meow_u128 Hash = MeowHash(MeowDefaultSeed, len, (void *)key);
    //long long unsigned Hash64 = MeowU64From(Hash, 0);
    int unsigned Hash32 = MeowU32From(Hash, 0);
    return Hash32;
}

// Timing
static inline double get_time_diff(struct timespec start, struct timespec end) {
    return (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    // Open file
    FILE *fd = fopen(argv[1], "rb");
    if (!fd) {
        perror("Failed to open file");
        return 1;
    }

    // Get file size
	fseeko(fd, 0, SEEK_END);
    off_t file_size = ftello(fd);
    if (file_size < 0) {
        perror("Failed to stat file");
        fclose(fd);
        return 1;
    }
	fseeko(fd, 0, SEEK_SET);

    // Allocate buffer
    char *buffer = malloc(file_size + MAX_BB_SIZE);
    if (!buffer) {
        fprintf(stderr, "Failed to allocate buffer\n");
        fclose(fd);
        return 1;
    }

            printf("%s %llu\n",
                   "Size:", file_size);

    // Read file
    size_t bytes_read = fread(buffer, 1, file_size, fd);

            printf("%s %llu\n",
                   "Read:", bytes_read);

    if (bytes_read != (size_t)file_size) {
        fprintf(stderr, "Failed to read file\n");
        free(buffer);
        fclose(fd);
        return 1;
    }
    fclose(fd);

    // Zero-pad end
    memset(buffer + file_size, 0, MAX_BB_SIZE);

    // Allocate hash table (512MB bit array)
    uint8_t *hash_table = calloc(HASH_TABLE_BYTES, 1);
    if (!hash_table) {
        fprintf(stderr, "Failed to allocate hash table\n");
        free(buffer);
        return 1;
    }

    // BB sizes
    size_t bb_sizes[] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 26, 28, 30, 32, 48, 64, 80, 96, 128, 256, 512, 1024, 2048, 8192};
    size_t num_bb_sizes = sizeof(bb_sizes) / sizeof(bb_sizes[0]);

    // Hashers
    struct {
        const char *name;
        uint32_t (*hash)(const char *, size_t);
    } hashers[] = {
        {"MeowHash", MeowHash_wrapper},
        {"Pippip_AES_TriXZi_Mikayla", Pippip_AES_TriXZi_Mikayla_wrapper}, //slothash = (uint64_t)FNV1A_Pippip_Yurii_OOO_128bit_AES(SourceBlock+k64*128LL, 128);
//        {"Bernstein", Bernstein_wrapper}, //slothash = (uint64_t)FNV1A_Pippip_Yurii_OOO_128bit_AES(SourceBlock+k64*128LL, 128);
//        {"Pippip_AES_Tri", Pippip_AES_Tri_wrapper}, //slothash = (uint64_t)FNV1A_Pippip_Yurii_OOO_128bit_AES(SourceBlock+k64*128LL, 128);
        {"wyhash f4", wyhash_wrapper}, //slothash = (uint64_t)wyhash(SourceBlock+k64*128LL, 128, 0, _wyp);
        {"komihash 5.27", komihash_wrapper}, //slothash = (uint64_t)komihash(SourceBlock+k64*128LL, 128, 0);
        {"XXH3_64bits 0.8.3", XXH3_64bits_wrapper} //slothash = (uint64_t)komihash(SourceBlock+k64*128LL, 128, 0);
    };
    size_t num_hashers = sizeof(hashers) / sizeof(hashers[0]);

    // Output header
    printf("Hasher,BB_Size,Total_Hashes,Unique_Hashes,Collisions,Time_s,Speed_GBs,SpeedRAW_GBs\n");

    // Benchmark
    for (size_t h = 0; h < num_hashers; h++) {
        for (size_t b = 0; b < num_bb_sizes; b++) {
            size_t bb_size = bb_sizes[b];
            if (bb_size > file_size) continue;

            // Clear hash table
            memset(hash_table, 0, HASH_TABLE_BYTES);

            // Count total hashes
            uint64_t total_hashes = file_size - bb_size + 1;
    volatile size_t dummysum = 0;

            // Time hashing
            struct timespec start, end;
            clock_gettime(CLOCK_MONOTONIC, &start);
// this was uncommented for r2
/*
			if (h == 0) {
						// Hash all BBs
						for (size_t i = 0; i <= file_size - bb_size; i++) {
						    hash = FNV1A_Pippip_Yurii_OOO_128bit_AES_Tri(buffer + i, bb_size);
						    set_bit(hash_table, hash);
						}
			} else if (h==1) {
						// Hash all BBs
						for (size_t i = 0; i <= file_size - bb_size; i++) {
						    hash = wyhash(buffer + i, bb_size, 0, _wyp);
						    set_bit(hash_table, hash);
						}
			} else {
						// Hash all BBs
						for (size_t i = 0; i <= file_size - bb_size; i++) {
						    hash = komihash(buffer + i, bb_size, 0);
						    set_bit(hash_table, hash);
						}
			}
*/
// this was commented for r2
            // Hash all BBs
            for (size_t i = 0; i <= file_size - bb_size; i++) {
                uint32_t hash = hashers[h].hash(buffer + i, bb_size);
                set_bit(hash_table, hash);
            }

            clock_gettime(CLOCK_MONOTONIC, &end);

            // Count unique hashes
            uint64_t unique_hashes = count_bits(hash_table, HASH_TABLE_BYTES);
            uint64_t collisions = total_hashes - unique_hashes;

            // Calculate metrics
            double time_s = get_time_diff(start, end);
            double total_bytes = total_hashes * bb_size;
            double speed_gbs = ((total_bytes) / (time_s)) /1024/1024/1024;

            clock_gettime(CLOCK_MONOTONIC, &start);
            for (size_t i = 0; i <= file_size - bb_size; i++) {
                uint32_t hash = hashers[h].hash(buffer + i, bb_size);
                dummysum += hash;
            }
            clock_gettime(CLOCK_MONOTONIC, &end);
            double time_RAWs = get_time_diff(start, end);
            double speed_RAWgbs = ((total_bytes) / (time_RAWs)) /1024/1024/1024;

            // Output results
            printf("%s,\t%zu,\t%llu,\t%llu,\t\t%llu,\t%.3f,\t%.3f,\t%.3f\n",
                   hashers[h].name, bb_size, total_hashes, unique_hashes,
                   collisions, time_s,speed_gbs, speed_RAWgbs);
        }
    }

    // Cleanup
    free(hash_table);
    free(buffer);
    return 0;
}

// Benchmark 'hashBB' r3 - 32bit hashtable extravaganza
// Fedora Linux Release 41 (MATE-Compiz) 64-bit
// Kernel Linux 6.12.13-200.fc41.x86_64 x86_64
// Compiler: gcc 14.2.1
// Compiler options: gcc -O3 -mavx2 -march=skylake hashBBs_r2.c -o hashBBs_r2_skylake.elf
// Testmachine: DELL Latitude 7370, m7-6Y75 'Skylake', TDP: 4.5 W (up to 7 W), CPU max 3100 MHz, 2x4GB LPDDR3 1867 MT/s
// +------------------------------+---------+--------------+---------------+-------------+--------------+
// | Hasher, GCC                  | BB_Size | Total_Hashes | Unique_Hashes |  Collisions |    Speed_GBs |
// +------------------------------+---------+--------------+---------------+-------------+--------------+
// | Pippip_AES_Tri, (64bit hash) |       2 |  999,999,999 |        22,664 | 999,977,335 |  0.361 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |       4 |  999,999,997 |     3,221,008 | 996,778,989 |  0.281 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |       6 |  999,999,995 |    28,152,805 | 971,847,190 |  0.280 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |       8 |  999,999,993 |    87,056,712 | 912,943,281 |  0.329 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      10 |  999,999,991 |   177,069,062 | 822,930,929 |  0.339 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |      12 |  999,999,989 |   284,922,476 | 715,077,513 |  0.394 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      14 |  999,999,987 |   389,950,899 | 610,049,088 |  0.450 GiB/s | ! Fastest ! 
// | Pippip_AES_Tri, (64bit hash) |      16 |  999,999,985 |   479,337,593 | 520,662,392 |  0.506 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |      18 |  999,999,983 |   548,857,409 | 451,142,574 |  0.614 GiB/s | ! Fastest ! 
// | Pippip_AES_Tri, (64bit hash) |      20 |  999,999,981 |   600,531,528 | 399,468,453 |  0.677 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |      22 |  999,999,979 |   638,067,863 | 361,932,116 |  0.738 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      24 |  999,999,977 |   665,401,785 | 334,598,192 |  0.693 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      26 |  999,999,975 |   685,533,395 | 314,466,580 |  0.854 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      28 |  999,999,973 |   701,040,164 | 298,959,809 |  0.912 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      30 |  999,999,971 |   713,429,903 | 286,570,068 |  0.975 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      32 |  999,999,969 |   723,819,696 | 276,180,273 |  1.036 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      48 |  999,999,953 |   772,543,232 | 227,456,721 |  1.300 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |      64 |  999,999,937 |   801,678,706 | 198,321,231 |  1.709 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |      96 |  999,999,905 |   836,284,386 | 163,715,519 |  2.426 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |     128 |  999,999,873 |   858,297,349 | 141,702,524 |  2.794 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |     256 |  999,999,745 |   885,182,548 | 114,817,197 |  4.250 GiB/s | ! Fastest ! Best Dispersion !
// | Pippip_AES_Tri, (64bit hash) |     512 |  999,999,489 |   890,282,974 | 109,716,515 |  5.784 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |   1,024 |  999,998,977 |   891,648,318 | 108,350,659 |  6.316 GiB/s | ! Fastest !
// | Pippip_AES_Tri, (64bit hash) |   8,192 |  999,991,809 |   892,081,237 | 107,910,572 |  9.532 GiB/s |           ! Best Dispersion !
// +------------------------------+---------+--------------+---------------+-------------+--------------+
//                                                     Total Collisions = 10,445,575,720
// +------------------------------+---------+--------------+---------------+-------------+--------------+
// | wyhash f4,      (64bit hash) |       2 |  999,999,999 |        22,664 | 999,977,335 |  0.310 GiB/s |
// | wyhash f4,      (64bit hash) |       4 |  999,999,997 |     3,221,038 | 996,778,959 |  0.249 GiB/s |
// | wyhash f4,      (64bit hash) |       6 |  999,999,995 |    28,152,656 | 971,847,339 |  0.247 GiB/s |
// | wyhash f4,      (64bit hash) |       8 |  999,999,993 |    87,055,889 | 912,944,104 |  0.283 GiB/s | 
// | wyhash f4,      (64bit hash) |      10 |  999,999,991 |   177,065,276 | 822,934,715 |  0.331 GiB/s | 
// | wyhash f4,      (64bit hash) |      12 |  999,999,989 |   284,925,807 | 715,074,182 |  0.384 GiB/s |           ! Best Dispersion !
// | wyhash f4,      (64bit hash) |      14 |  999,999,987 |   389,956,222 | 610,043,765 |  0.436 GiB/s |           ! Best Dispersion !
// | wyhash f4,      (64bit hash) |      16 |  999,999,985 |   479,335,148 | 520,664,837 |  0.464 GiB/s |
// | wyhash f4,      (64bit hash) |      18 |  999,999,983 |   548,862,626 | 451,137,357 |  0.517 GiB/s |           ! Best Dispersion !
// | wyhash f4,      (64bit hash) |      20 |  999,999,981 |   600,528,983 | 399,470,998 |  0.570 GiB/s | 
// | wyhash f4,      (64bit hash) |      22 |  999,999,979 |   638,069,525 | 361,930,454 |  0.618 GiB/s |           ! Best Dispersion !
// | wyhash f4,      (64bit hash) |      24 |  999,999,977 |   665,410,094 | 334,589,883 |  0.670 GiB/s |
// | wyhash f4,      (64bit hash) |      26 |  999,999,975 |   685,527,707 | 314,472,268 |  0.720 GiB/s |
// | wyhash f4,      (64bit hash) |      28 |  999,999,973 |   701,040,393 | 298,959,580 |  0.770 GiB/s |
// | wyhash f4,      (64bit hash) |      30 |  999,999,971 |   713,424,856 | 286,575,115 |  0.821 GiB/s |
// | wyhash f4,      (64bit hash) |      32 |  999,999,969 |   723,832,432 | 276,167,537 |  0.778 GiB/s |
// | wyhash f4,      (64bit hash) |      48 |  999,999,953 |   772,554,162 | 227,445,791 |  1.082 GiB/s |
// | wyhash f4,      (64bit hash) |      64 |  999,999,937 |   801,678,263 | 198,321,674 |  1.365 GiB/s |
// | wyhash f4,      (64bit hash) |      96 |  999,999,905 |   836,269,895 | 163,730,010 |  1.496 GiB/s |
// | wyhash f4,      (64bit hash) |     128 |  999,999,873 |   858,300,607 | 141,699,266 |  1.827 GiB/s |
// | wyhash f4,      (64bit hash) |     256 |  999,999,745 |   885,153,510 | 114,846,235 |  3.339 GiB/s |
// | wyhash f4,      (64bit hash) |     512 |  999,999,489 |   890,291,225 | 109,708,264 |  3.479 GiB/s |
// | wyhash f4,      (64bit hash) |   1,024 |  999,998,977 |   891,646,667 | 108,352,310 |  5.786 GiB/s |
// | wyhash f4,      (64bit hash) |   8,192 |  999,991,809 |   892,076,379 | 107,915,430 | 13.811 GiB/s | ! Fastest !
// +------------------------------+---------+--------------+---------------+-------------+--------------+
//                                                     Total Collisions = 10,445,587,408
// +------------------------------+---------+--------------+---------------+-------------+--------------+
// | komihash 5.27,  (64bit hash) |       2 |  999,999,999 |        22,664 | 999,977,335 |  0.258 GiB/s |
// | komihash 5.27,  (64bit hash) |       4 |  999,999,997 |     3,221,077 | 996,778,920 |  0.239 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |       6 |  999,999,995 |    28,152,334 | 971,847,661 |  0.237 GiB/s |
// | komihash 5.27,  (64bit hash) |       8 |  999,999,993 |    87,057,912 | 912,942,081 |  0.269 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      10 |  999,999,991 |   177,068,361 | 822,931,630 |  0.317 GiB/s |
// | komihash 5.27,  (64bit hash) |      12 |  999,999,989 |   284,923,151 | 715,076,838 |  0.369 GiB/s | 
// | komihash 5.27,  (64bit hash) |      14 |  999,999,987 |   389,954,896 | 610,045,091 |  0.422 GiB/s | 
// | komihash 5.27,  (64bit hash) |      16 |  999,999,985 |   479,330,340 | 520,669,645 |  0.457 GiB/s |
// | komihash 5.27,  (64bit hash) |      18 |  999,999,983 |   548,851,725 | 451,148,258 |  0.505 GiB/s | 
// | komihash 5.27,  (64bit hash) |      20 |  999,999,981 |   600,508,295 | 399,491,686 |  0.556 GiB/s |
// | komihash 5.27,  (64bit hash) |      22 |  999,999,979 |   638,058,358 | 361,941,621 |  0.608 GiB/s |
// | komihash 5.27,  (64bit hash) |      24 |  999,999,977 |   665,412,672 | 334,587,305 |  0.649 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      26 |  999,999,975 |   685,543,027 | 314,456,948 |  0.703 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      28 |  999,999,973 |   701,043,732 | 298,956,241 |  0.749 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      30 |  999,999,971 |   713,452,731 | 286,547,240 |  0.796 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      32 |  999,999,969 |   723,836,638 | 276,163,331 |  0.702 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      48 |  999,999,953 |   772,561,065 | 227,438,888 |  0.972 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |      64 |  999,999,937 |   801,667,123 | 198,332,814 |  0.892 GiB/s |
// | komihash 5.27,  (64bit hash) |      96 |  999,999,905 |   836,266,006 | 163,733,899 |  1.261 GiB/s |
// | komihash 5.27,  (64bit hash) |     128 |  999,999,873 |   858,303,408 | 141,696,465 |  1.649 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |     256 |  999,999,745 |   885,178,746 | 114,820,999 |  1.862 GiB/s |
// | komihash 5.27,  (64bit hash) |     512 |  999,999,489 |   890,295,038 | 109,704,451 |  3.157 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |   1,024 |  999,998,977 |   891,654,212 | 108,344,765 |  5.098 GiB/s |           ! Best Dispersion !
// | komihash 5.27,  (64bit hash) |   8,192 |  999,991,809 |   892,072,065 | 107,919,744 | 10.661 GiB/s |
// +------------------------------+---------+--------------+---------------+-------------+--------------+ 
//                                                     Total Collisions = 10,445,553,856                  ! Best Dispersion !
// +------------------------------+---------+--------------+---------------+-------------+--------------+

// Testmachine: ThinkPad A285, AMD Ryzen 5 'Raven Ridge' PRO 2500U, TDP: 15 W (up to 25 W), CPU max 3600 MHz, 2x4GB DDR4 2400 MT/s

