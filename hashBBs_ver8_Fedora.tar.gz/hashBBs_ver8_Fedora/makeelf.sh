# The bare minimum:
# -static -O3 -mavx2 -maes -mbmi2

# AVX2 CPUs
gcc -static -O3 -march=tigerlake hashBBs_r8.c xxhash.c -o hashBBs_r8_GCC_tigerlake.elf
gcc -O3 -march=tigerlake hashBBs_r8.c -o hashBBs_r8_GCC_tigerlake.elf.asm -S

gcc -static -O3 -march=skylake hashBBs_r8.c xxhash.c -o hashBBs_r8_GCC_skylake.elf
gcc -O3 -march=skylake hashBBs_r8.c -o hashBBs_r8_GCC_skylake.elf.asm -S

gcc -static -O3 -march=znver4 hashBBs_r8.c xxhash.c -o hashBBs_r8_GCC_znver4.elf
gcc -O3 -march=znver4 hashBBs_r8.c -o hashBBs_r8_GCC_znver4.elf.asm -S

# NON-AVX2 CPUs
gcc -static -O3 -maes -march=ivybridge hashBBs_r8.c xxhash.c -o hashBBs_r8_GCC_ivybridge.elf
gcc -O3 -maes -march=ivybridge hashBBs_r8.c -o hashBBs_r8_GCC_ivybridge.elf.asm -S

