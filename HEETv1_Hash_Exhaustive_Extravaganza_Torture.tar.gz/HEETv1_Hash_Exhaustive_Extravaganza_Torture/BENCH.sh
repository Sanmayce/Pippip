# Run first $ su

lscpu
dmidecode --type 1
dmidecode --type 17

# Set CPU to performance mode for all CPUs
echo "Setting CPU to performance mode..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance | tee $cpu > /dev/null
done

cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

#gcc -static -O3 -march=native -o CollisionDepthReporter_torture_FNV1A32 CollisionDepthReporter_torture.c -DFNV1A32
clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIPfox CollisionDepthReporter_torture.c -DPIPPIPfox
clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIP CollisionDepthReporter_torture.c -DPIPPIP
clang -static -O3 -march=native -o CollisionDepthReporter_torture_WY CollisionDepthReporter_torture.c -DWY
clang -static -O3 -march=native -o CollisionDepthReporter_torture_FARM CollisionDepthReporter_torture.c farmhash-c.c -DFARM

gcc -static -O3 AllEnglishWords.c -o AllEnglishWords

./AllEnglishWords "$1">"$1".wrd

echo

if [ "$1" == "cmudict-0.7b.txt" ] ; then
echo "Hashing \"Carnegie Mellon University Pronunciation Dictionary\" Extravaganza Benchmark"
fi

if [ "$1" == "github.com_dwyl_english-words_blob_master_words_alpha.txt" ] ; then
echo "Hashing \"370,000+ English Wordlist\" Extravaganza Benchmark"
fi

echo

nice -n -20 ./CollisionDepthReporter_torture_PIPPIPfox "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_PIPPIP "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_WY "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_FARM "$1".wrd
#echo
#nice -n -20 ./CollisionDepthReporter_torture_FNV1A32 "$1".wrd

