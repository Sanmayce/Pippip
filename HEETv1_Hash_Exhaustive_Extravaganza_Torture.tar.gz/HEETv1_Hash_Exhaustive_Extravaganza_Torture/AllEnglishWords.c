// AllEnglishWords.c

/*
 * AllEnglishWords.c
 * Fast textual word frequency indexer using surgical UTF-8 lowercasing.
 * Extracts unique words up to 32 chars, lowercases them, and tallies occurrences.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define MAX_WORD_LEN 32
// Power of 2 required for fast bitwise AND modulo masking
#define HASH_CAPACITY 4194304 

typedef struct {
    char word[MAX_WORD_LEN + 1];
    uint32_t count;
} HashEntry;

// FNV-1a hash function for fast inline string hashing
static inline uint32_t hash_fnv1a(const char* key, size_t len) {
    uint32_t hash = 2166136261u;
    for (size_t i = 0; i < len; i++) {
        hash ^= (uint8_t)key[i];
        hash *= 16777619;
    }
    return hash;
}

// Fast linear probing open-addressing insertion
static inline void insert_word(HashEntry* table, const char* word, size_t len) {
    if (len == 0 || len > MAX_WORD_LEN) return;
    
    uint32_t idx = hash_fnv1a(word, len) & (HASH_CAPACITY - 1);
    
    while (table[idx].word[0] != '\0') {
        // If word exists, merge duplicate and increment count
        if (table[idx].word[len] == '\0' && memcmp(table[idx].word, word, len) == 0) {
            table[idx].count++;
            return;
        }
        idx = (idx + 1) & (HASH_CAPACITY - 1);
    }
    
    // Empty slot found, register unique word
    memcpy(table[idx].word, word, len);
    table[idx].word[len] = '\0';
    table[idx].count = 1;
}

// Qsort comparator for alphabetical sorting
int compare_entries(const void* a, const void* b) {
    return strcmp(((const HashEntry*)a)->word, ((const HashEntry*)b)->word);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE* fp = fopen(argv[1], "rb");
    if (!fp) {
        perror("Failed to open file");
        return 1;
    }

    // Determine file size for single-pass buffering
    fseek(fp, 0, SEEK_END);
    size_t file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    unsigned char* file_buffer = (unsigned char*)malloc(file_size);
    if (!file_buffer) {
        fprintf(stderr, "Failed to allocate memory for file buffer\n");
        fclose(fp);
        return 1;
    }

    if (fread(file_buffer, 1, file_size, fp) != file_size) {
        fprintf(stderr, "Failed to read full file\n");
        free(file_buffer);
        fclose(fp);
        return 1;
    }
    fclose(fp);

    HashEntry* table = (HashEntry*)calloc(HASH_CAPACITY, sizeof(HashEntry));
    if (!table) {
        fprintf(stderr, "Failed to allocate memory for hash table\n");
        free(file_buffer);
        return 1;
    }

    // ASCII LUT: Maps A-Z to a-z
    unsigned char ascii_map[256] = {0};
    for (int i = 'A'; i <= 'Z'; i++) ascii_map[i] = i + 32;
    for (int i = 'a'; i <= 'z'; i++) ascii_map[i] = i;

    // German UTF-8 surgical map: Targets the second byte of a 0xC3 sequence
    unsigned char c3_map[256] = {0};
    c3_map[0x84] = 0xA4; // Ä -> ä
    c3_map[0x96] = 0xB6; // Ö -> ö
    c3_map[0x9C] = 0xBC; // Ü -> ü
    c3_map[0xA4] = 0xA4; // ä
    c3_map[0xB6] = 0xB6; // ö
    c3_map[0xBC] = 0xBC; // ü
    c3_map[0x9F] = 0x9F; // ß

    char word_buf[MAX_WORD_LEN + 1];
    size_t wlen = 0;
    int in_word = 0;

    // Single-pass sweep mapping characters and building words inline
    for (size_t i = 0; i < file_size; i++) {
        unsigned char c = file_buffer[i];
        unsigned char mapped_ascii = ascii_map[c];

        if (mapped_ascii) {
            if (wlen < MAX_WORD_LEN) {
                word_buf[wlen++] = mapped_ascii;
            }
            in_word = 1;
        } 
/*
        else if (c == 0xC3 && i + 1 < file_size) {
            unsigned char c2 = file_buffer[i + 1];
            unsigned char mapped_c3 = c3_map[c2];
            
            if (mapped_c3) {
                // Ensure room for both bytes up to the 32 char limit
                if (wlen + 1 <= MAX_WORD_LEN) {
                    word_buf[wlen++] = 0xC3;
                    word_buf[wlen++] = mapped_c3;
                }
                in_word = 1;
                i++; // Consume the targeted second byte
            } else {
                // Invalid/Unsupported C3 sequence triggers a delimiter stop
                if (in_word) {
                    insert_word(table, word_buf, wlen);
                    wlen = 0;
                    in_word = 0;
                }
            }
        } 
*/
        else {
            // Any unmapped byte is treated as a delimiter separating words
            if (in_word) {
                insert_word(table, word_buf, wlen);
                wlen = 0;
                in_word = 0;
            }
        }
    }
    
    // Flush trailing word if EOF hits without a terminating whitespace
    if (in_word) {
        insert_word(table, word_buf, wlen);
    }
    free(file_buffer);

    // Extract unique entries into a contiguous block
    HashEntry* unique_words = (HashEntry*)malloc(HASH_CAPACITY * sizeof(HashEntry));
    size_t unique_count = 0;

    for (size_t i = 0; i < HASH_CAPACITY; i++) {
        if (table[i].word[0] != '\0') {
            unique_words[unique_count++] = table[i];
        }
    }
    free(table);

    // Sort the index alphabetically
    qsort(unique_words, unique_count, sizeof(HashEntry), compare_entries);

    // Output strictly as "word count"
    for (size_t i = 0; i < unique_count; i++) {
        //printf("%s %u\n", unique_words[i].word, unique_words[i].count);
        printf("%s\n", unique_words[i].word);
    }

    free(unique_words);
    return 0;
}
