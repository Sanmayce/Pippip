# The bare minimum:
# -static -O3 -mavx2 -maes -mbmi2

# AVX512f CPUs
gcc -DZMM -static -O3 -march=tigerlake hashBBs_r9.c xxhash.c -o hashBBs_r9_GCC_tigerlakeZMM.elf
gcc -DZMM -O3 -march=tigerlake hashBBs_r9.c -o hashBBs_r9_GCC_tigerlakeZMM.elf.asm -S

gcc -DZMM -static -O3 -march=znver4 hashBBs_r9.c xxhash.c -o hashBBs_r9_GCC_znver4ZMM.elf
gcc -DZMM -O3 -march=znver4 hashBBs_r9.c -o hashBBs_r9_GCC_znver4ZMM.elf.asm -S

# AVX2 CPUs
gcc -static -O3 -march=skylake hashBBs_r9.c xxhash.c -o hashBBs_r9_GCC_skylake.elf
gcc -O3 -march=skylake hashBBs_r9.c -o hashBBs_r9_GCC_skylake.elf.asm -S

gcc -static -O3 -march=znver1 hashBBs_r9.c xxhash.c -o hashBBs_r9_GCC_znver1.elf
gcc -O3 -march=znver1 hashBBs_r9.c -o hashBBs_r9_GCC_znver1.elf.asm -S

# NON-AVX2 CPUs
gcc -static -O3 -maes -march=ivybridge hashBBs_r9.c xxhash.c -o hashBBs_r9_GCC_ivybridge.elf
gcc -O3 -maes -march=ivybridge hashBBs_r9.c -o hashBBs_r9_GCC_ivybridge.elf.asm -S

gcc -static -O3 -maes -march=goldmont-plus hashBBs_r9.c xxhash.c -o hashBBs_r9_GCC_GeminiLake.elf
gcc -O3 -maes -march=goldmont-plus hashBBs_r9.c -o hashBBs_r9_GCC_GeminiLake.elf.asm -S

