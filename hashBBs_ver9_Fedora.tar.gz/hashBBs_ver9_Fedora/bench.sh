# Run first $ su

lscpu
dmidecode --type 1
dmidecode --type 17

# Set CPU to performance mode for all CPUs
echo "Setting CPU to performance mode..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance | tee $cpu > /dev/null
done

cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

nice -n -20 ./hashBBs_r9_GCC_tigerlakeZMM.elf "$1"
#nice -n -20 ./hashBBs_r9_GCC_tigerlake.elf "$1"
#nice -n -20 ./hashBBs_r9_GCC_skylake.elf "$1"
#nice -n -20 ./hashBBs_r9_GCC_znver1.elf "$1"
#nice -n -20 ./hashBBs_r9_GCC_znver4.elf "$1"
#nice -n -20 ./hashBBs_r9_GCC_ivybridge.elf "$1"
#nice -n -20 ./hashBBs_r9_GCC_GeminiLake.elf "$1"
echo 

