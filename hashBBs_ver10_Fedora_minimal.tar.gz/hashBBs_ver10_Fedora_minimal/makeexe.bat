gcc -O3 -mavx2 -march=skylake hashBBs_r7.c xxhash.c -o hashBBs_r7_skylake.exe -D_FILE_OFFSET_BITS=64
gcc -O3 -mavx2 -march=skylake hashBBs_r7.c -o hashBBs_r7_skylake.exe.asm -S
