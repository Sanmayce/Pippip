# Run first $ su

lscpu
dmidecode --type 1
dmidecode --type 17

# Set CPU to performance mode for all CPUs
echo "Setting CPU to performance mode..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance | tee $cpu > /dev/null
done

cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

gcc -static -O3 AllEnglishWords.c -o AllEnglishWords

./AllEnglishWords "$1">"$1".wrd

echo

if [ "$1" == "cmudict-0.7b.txt" ] ; then
echo "Hashing \"Carnegie Mellon University Pronunciation Dictionary\" Extravaganza Benchmark"
fi

if [ "$1" == "github.com_dwyl_english-words_blob_master_words_alpha.txt" ] ; then
echo "Hashing \"370,000+ English Wordlist\" Extravaganza Benchmark"
fi

echo

clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIPfox CollisionDepthReporter_torture.c -DPIPPIPfox -DRAWSPEED
clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIP CollisionDepthReporter_torture.c -DPIPPIP -DRAWSPEED
clang -static -O3 -march=native -o CollisionDepthReporter_torture_WY CollisionDepthReporter_torture.c -DWY -DRAWSPEED
clang -static -O3 -march=native -o CollisionDepthReporter_torture_FARM CollisionDepthReporter_torture.c farmhash-c.c -DFARM -DRAWSPEED
clang -static -O3 -march=native -o CollisionDepthReporter_torture_RAPID CollisionDepthReporter_torture.c -DRAPID -DRAWSPEED
clang -static -O3 -march=native -o CollisionDepthReporter_torture_PYF CollisionDepthReporter_torture.c -DPYF -DRAWSPEED

nice -n -20 ./CollisionDepthReporter_torture_PYF "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_RAPID "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_PIPPIPfox "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_PIPPIP "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_WY "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_FARM "$1".wrd

clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIPfox CollisionDepthReporter_torture.c -DPIPPIPfox
clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIP CollisionDepthReporter_torture.c -DPIPPIP
clang -static -O3 -march=native -o CollisionDepthReporter_torture_WY CollisionDepthReporter_torture.c -DWY
clang -static -O3 -march=native -o CollisionDepthReporter_torture_FARM CollisionDepthReporter_torture.c farmhash-c.c -DFARM
clang -static -O3 -march=native -o CollisionDepthReporter_torture_RAPID CollisionDepthReporter_torture.c -DRAPID
clang -static -O3 -march=native -o CollisionDepthReporter_torture_PYF CollisionDepthReporter_torture.c -DPYF

nice -n -20 ./CollisionDepthReporter_torture_PYF "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_RAPID "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_PIPPIPfox "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_PIPPIP "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_WY "$1".wrd
echo
nice -n -20 ./CollisionDepthReporter_torture_FARM "$1".wrd

