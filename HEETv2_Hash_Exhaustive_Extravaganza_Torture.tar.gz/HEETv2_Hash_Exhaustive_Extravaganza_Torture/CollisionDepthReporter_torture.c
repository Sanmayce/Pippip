// CollisionDepthReporter_torture.c, v2, Written by Grok AI and Kaze (sanmayce@sanmayce.com), 2026-Aug-28

// clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIPfox CollisionDepthReporter_torture.c -DPIPPIPfox
// clang -static -O3 -march=native -o CollisionDepthReporter_torture_PIPPIP CollisionDepthReporter_torture.c -DPIPPIP
// clang -static -O3 -march=native -o CollisionDepthReporter_torture_WY CollisionDepthReporter_torture.c -DWY
// clang -static -O3 -march=native -o CollisionDepthReporter_torture_FARM CollisionDepthReporter_torture.c farmhash-c.c -DFARM
// clang -static -O3 -march=native -o CollisionDepthReporter_torture_RAPID CollisionDepthReporter_torture.c -DRAPID
// clang -static -O3 -march=native -o CollisionDepthReporter_torture_PYF CollisionDepthReporter_torture.c -DPYF

/*
README.DIZ
==========

CollisionDepthReporter_torture - 32-bit hash collision torture test using case variants

What it does:
  Reads a text file containing English words (one word per line).
  Enforced word length limitation: 32 bytes.
  For every word it generates ALL possible upper/lower-case combinations
  and feeds each of them into a 16 GB table of 32-bit counters using
  the 'FNV-1a' or 'Pippip_4HEADS' 32-bit hashers.

  At the end it reports:
    - Total number of keys hashed
    - The deepest collision found
    - How many slots share that maximum depth

This is a practical stress test for 32-bit hash functions.

Usage:
  ./CollisionDepthReporter_torture wordlist.txt
  ./CollisionDepthReporter_torture wordlist.txt 1000000000   (optional limit)

Requirements:
  - 64-bit Linux
  - At least 20 GB free RAM (16 GB for the table)
  - gcc (compile with: gcc -O3 -march=native -o CollisionDepthReporter_torture CollisionDepthReporter_torture.c -DFNV1A32)

Example of full expansion for the word "brutal" (64 variants):

brutal
Brutal
bRutal
brUtal
bruTal
brutAl
brutaL
BRutal
BrUtal
BruTal
BrutAl
BrutaL
bRUtal
bRuTal
bRutAl
bRutaL
brUTal
brUtAl
brUtaL
bruTAl
bruTaL
brutAL
BRUtal
BRuTal
BRutAl
BRutaL
BrUTal
BrUtAl
BrUtaL
BruTAl
BruTaL
BrutAL
bRUTal
bRUtAl
bRUtaL
bRuTAl
bRuTaL
bRutAL
brUTAl
brUTaL
brUtAL
bruTAL
BRUTal
BRUtAl
BRUtaL
BRuTAl
BRuTaL
BRutAL
BrUTAl
BrUTaL
BrUtAL
BruTAL
bRUTAl
bRUTaL
bRUtAL
bRuTAL
brUTAL
BRUTAl
BRUTaL
BRUtAL
BRuTAL
BrUTAL
bRUTAL
BRUTAL

Each of the above 64 strings is hashed separately.
*/

// case_hash_torture.c
// Compile:  gcc -O3 -march=native -o case_hash case_hash_torture.c
// Usage:    ./case_hash wordlist.txt
//           ./case_hash wordlist.txt 1000000000

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdbool.h>

#include "Pippip.h"

#include "wyhash32.h"

#include "farmhash-c.h"
#include "rapidhash.h"

#define MAX_WORD     64
#define TABLE_SIZE   (1ULL << 32)
#define TABLE_BYTES  (TABLE_SIZE * 4ULL)      // 16 GB

static uint32_t *table = NULL;
static uint64_t total_hashed = 0;
static uint64_t total_lines_hashed = 0;
static uint64_t EmptySlots = 0;
static uint64_t TotalKeysLen = 0;
static uint64_t max_variants = UINT64_MAX;

uint64_t SimulateActivity;

void x64toaKAZE (      /* stdcall is faster and smaller... Might as well use it for the helper. */
        unsigned long long val,
        char *buf,
        unsigned radix,
        int is_neg
        )
{
        char *p;                /* pointer to traverse string */
        char *firstdig;         /* pointer to first digit */
        char temp;              /* temp char */
        unsigned digval;        /* value of digit */

        p = buf;

        if ( is_neg )
        {
            *p++ = '-';         /* negative, so output '-' and negate */
            val = (unsigned long long)(-(long long)val);
        }

        firstdig = p;           /* save pointer to first digit */

        do {
            digval = (unsigned) (val % radix);
            val /= radix;       /* get next digit */

            /* convert to ascii and store */
            if (digval > 9)
                *p++ = (char) (digval - 10 + 'a');  /* a letter */
            else
                *p++ = (char) (digval + '0');       /* a digit */
        } while (val > 0);

        /* We now have the digit of the number in the buffer, but in reverse
           order.  Thus we reverse them now. */

        *p-- = '\0';            /* terminate string; p points to last digit */

        do {
            temp = *p;
            *p = *firstdig;
            *firstdig = temp;   /* swap *p and *firstdig */
            --p;
            ++firstdig;         /* advance to next two digits */
        } while (firstdig < p); /* repeat until halfway */
}

/* Actual functions just call conversion helper with neg flag set correctly,
   and return pointer to buffer. */

char * _i64toaKAZE (
        long long val,
        char *buf,
        int radix
        )
{
        x64toaKAZE((unsigned long long)val, buf, radix, (radix == 10 && val < 0));
        return buf;
}

char * _ui64toaKAZE (
        unsigned long long val,
        char *buf,
        int radix
        )
{
        x64toaKAZE(val, buf, radix, 0);
        return buf;
}

char * _ui64toaKAZEzerocomma (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        do
                        { if (buf <= p)
                          { temp = *p;
                            buf[26-txpman] = temp; pxnman++;
                            p--;
                            if (pxnman % 3 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          else
                          { buf[26-txpman] = (char) ('0'); pxnman++;
                            if (pxnman % 3 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          txpman++;
                        } while (txpman <= 26);
        return buf;
}

char * _ui64toaKAZEcomma (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        while (buf <= p)
                        { temp = *p;
                          buf[26-txpman] = temp; pxnman++;
                          p--;
                          if (pxnman % 3 == 0 && buf <= p)
                          { txpman++;
                            buf[26-txpman] = (char) (',');
                          }
                          txpman++;
                        } 
        return buf+26-(txpman-1);
}

char * _ui64toaKAZEzerocomma4 (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        do
                        { if (buf <= p)
                          { temp = *p;
                            buf[26-txpman] = temp; pxnman++;
                            p--;
                            if (pxnman % 4 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          else
                          { buf[26-txpman] = (char) ('0'); pxnman++;
                            if (pxnman % 4 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          txpman++;
                        } while (txpman <= 26);
        return buf;
}

char llTOaDigits[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
// below duplicates are needed because of one_line_invoking need different buffers.
char llTOaDigits2[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
char llTOaDigits3[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
char llTOaDigits4[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
char llTOaDigits5[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)

// FNV-1a 32-bit
static uint32_t fnv1a32(const char *key, size_t len) {
    uint32_t h = 2166136261u;          // FNV offset basis
    for (size_t i = 0; i < len; i++) {
        h ^= (uint8_t)key[i];
        h *= 16777619u;                // FNV prime
    }
    return h;
}

//also used in perl5 as djb2
// objsize: 0x13a0-0x13c9: 41
uint32_t
Bernstein(const char *key, int len, uint32_t seed)
{
  const uint8_t  *data = (const uint8_t *)key;
  const uint8_t *const end = &data[len];
  while (data < end) {
    //seed = ((seed << 5) + seed) + *data++;
    seed = 33 * seed + *data++;
  }
  return seed;
}

static void process_word(const char *word) {
    size_t len = strlen(word);
    #ifdef PermuteNOT
		if (len == 0 || len > 64) {
		    fprintf(stderr, "Skipping '%s' (length %zu)\n", word, len);
		    return;
		}
    #else
		if (len == 0 || len > 32) {
		    fprintf(stderr, "Skipping '%s' (length %zu)\n", word, len);
		    return;
		}
    #endif

    uint64_t total = 1ULL << len;
    char buf[MAX_WORD];

    #ifdef PermuteNOT
		total = 1;
    #endif

    for (uint64_t mask = 0; mask < total; mask++) {
        if (total_hashed >= max_variants) return;

        for (size_t i = 0; i < len; i++) {
            char c = tolower((unsigned char)word[i]);
            buf[i] = (mask & (1ULL << i)) ? toupper(c) : c;
        }
        buf[len] = '\0';

        uint32_t h;

    #ifdef FNV1A32
		h = fnv1a32(buf, len);
    #endif
    #ifdef PIPPIP
		FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla (buf, len, 0, &h); // buf[MAX_WORD] where MAX_WORD is 64 ensures reading-past-the-end-of-key is safe
    #endif
    #ifdef PIPPIPfox
		FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_FOX (buf, len, 0, &h); // buf[MAX_WORD] where MAX_WORD is 64 ensures reading-past-the-end-of-key is safe
    #endif
    #ifdef WY
		h = (uint32_t)wyhash32(buf, len, 0);
    #endif
    #ifdef FARM
		h = (uint32_t)farmhash32(buf, len);
    #endif
    #ifdef RAPID
		h = (uint32_t)rapidhash(buf, len);
    #endif
    #ifdef PYF
		h = (uint32_t)Pippip_scalar_LesFleursDuMal(buf, len, 0);
    #endif

		TotalKeysLen = TotalKeysLen + len;

    #ifdef RAWSPEED
		SimulateActivity += h;
    #else
        table[h]++;
    #endif

        total_hashed++;

        // Print every 2^30 = 1 073 741 824 keys (1 GiB of keys)
        if ((total_hashed & 0x3FFFFFFFULL) == 0) {
            printf("\rHashed keys so far: %llu; Hashed lines so far: %llu; DUMMY: %llu", (unsigned long long)total_hashed, (unsigned long long)total_lines_hashed, (unsigned long long)SimulateActivity);
            fflush(stdout);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <wordlist.txt> [max_variants]\n", argv[0]);
        return 1;
    }

    if (argc >= 3)
        max_variants = strtoull(argv[2], NULL, 10);

    printf("Allocating (using mmap) 16 GB = (4 bytes) x (2^32 slots) counter table...\n");
    table = mmap(NULL, TABLE_BYTES,
                 PROT_READ | PROT_WRITE,
                 MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (table == MAP_FAILED) {
        perror("mmap failed - need at least 16-20 GB free RAM");
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Cannot open word list");
        return 1;
    }

    char line[MAX_WORD];
    clock_t t0 = clock();

    #ifdef FNV1A32
    printf("Processing words and all case variants (FNV-1a 32-bit)...\n");
    #endif
    #ifdef PIPPIP
    printf("Processing words and all case variants (Pippip_4HEADS 128-bit)...\n");
    #endif
    #ifdef PIPPIPfox
    printf("Processing words and all case variants (Pippip_FOX 128-bit)...\n");
    #endif
    #ifdef WY
    printf("Processing words and all case variants (wyhash32 32-bit)...\n");
    #endif
    #ifdef FARM
    printf("Processing words and all case variants (farmhash32 32-bit)...\n");
    #endif
    #ifdef RAPID
    printf("Processing words and all case variants (rapidhash 64-bit)...\n");
    #endif
    #ifdef PYF
    printf("Processing words and all case variants (Pippip_scalar_LesFleursDuMal 32-bit)...\n");
    #endif

    while (fgets(line, sizeof(line), fp)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (line[0] == '\0') continue;
        process_word(line);
		total_lines_hashed++;
        if (total_hashed >= max_variants) break;
    }
    fclose(fp);

    double sec = (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("\n\nFinished. Total variants hashed: %llu in %.1f seconds\n",
           (unsigned long long)total_hashed, sec);

    printf("Scanning ~4 (%llu) billion slots for Maximum-Collision-Depth...\n", (unsigned long long)TABLE_SIZE);
    uint32_t max_val = 0;
    uint64_t max_count = 0;

    for (uint64_t i = 0; i < TABLE_SIZE; i++) {
        uint32_t v = table[i];
        if (v == 0) EmptySlots++;
        if (v > max_val) {
            max_val = v;
            max_count = 1;
        } else if (v == max_val && max_val > 0) {
            max_count++;
        }
    }

    printf("\n");
    printf("---------------------------------------- [ RESULT ] ----------------------------------------\n");
    #ifdef FNV1A32
    printf("Hasher                                                               : FNV-1a 32-bit\n");
    #endif
    #ifdef PIPPIP
    printf("Hasher                                                               : Pippip_4HEADS 128-bit\n");
    #endif
    #ifdef PIPPIPfox
    printf("Hasher                                                               : Pippip_FOX 128-bit\n");
    #endif
    #ifdef WY
    printf("Hasher                                                               : wyhash32 32-bit\n");
    #endif
    #ifdef FARM
    printf("Hasher                                                               : farmhash32 32-bit\n");
    #endif
    #ifdef RAPID
    printf("Hasher                                                               : rapidhash 64-bit\n");
    #endif
    #ifdef PYF
    printf("Hasher                                                               : Pippip_scalar_LesFleursDuMal 32-bit\n");
    #endif
    //printf("Hash Table slots                                                     : %llu\n", (unsigned long long)TABLE_SIZE);
    //printf("Total (unique) keys hashed                                           : %llu\n", (unsigned long long)total_hashed);
    //printf("Keys:Slots ratio                                                     : %.2f\n", (double)total_hashed/TABLE_SIZE);
    //printf("Hashing Speed, in Keys-Per-Second                                    : %.0f\n", (double)total_hashed/sec);
    printf("Hash Table slots                                                     : %s\n", _ui64toaKAZEcomma(TABLE_SIZE, llTOaDigits2, 10));
    printf("Total (unique) keys hashed                                           : %s\n", _ui64toaKAZEcomma(total_hashed, llTOaDigits2, 10));
    printf("Keys:Slots ratio                                                     : %.2f\n", (double)total_hashed/TABLE_SIZE);

    #ifdef RAWSPEED
    printf("Hashing RAW Speed, in Keys-Per-Second                                : %s\n", _ui64toaKAZEcomma(total_hashed/sec, llTOaDigits2, 10));
    #else
    printf("Hashing [plus LookUp] Speed, in Keys-Per-Second                      : %s\n", _ui64toaKAZEcomma(total_hashed/sec, llTOaDigits2, 10));
    #endif

    printf("Average Key Length                                                   : %s\n", _ui64toaKAZEcomma(TotalKeysLen/total_hashed, llTOaDigits2, 10));

    #ifdef RAWSPEED
    #else
    printf("Maximum-Collision-Depth (within a single slot), The-Lower-The-Better : %u\n", max_val);
    printf("Number of slots with MCD, The-Lower-The-Better                       : %llu\n", (unsigned long long)max_count);
    //printf("Empty Slots, The-Lower-The-Better                                    : %llu\n", (unsigned long long)EmptySlots);
    printf("Empty Slots, The-Lower-The-Better                                    : %s\n", _ui64toaKAZEcomma(EmptySlots, llTOaDigits2, 10));
    printf("Dispersion Quality: 100%% - (Empty Slots * 100%% / Total Slots)        : %.4f%%\n", 100-EmptySlots*100.0f/TABLE_SIZE);
    #endif

    printf("--------------------------------------------------------------------------------------------\n");

    munmap(table, TABLE_BYTES);
    return 0;
}

