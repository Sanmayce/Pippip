/*
If you want a clean English word list from an EnWiktionary dump, you need to parse the page structure, not just grep titles.

The program below:

- Parses <page> records.
- Requires <ns>0</ns>.
- Skips redirects.
- Filters titles to reasonable word-like entries.
- Keeps only entries containing an ==English== section.

It uses only the C standard library and streams the XML file line-by-line, so memory usage stays low even for huge dumps.
*/

// gcc -O3 -march=native -o enwiktionary_wordlist enwiktionary_wordlist.c
// ./enwiktionary_wordlist enwiktionary.xml > words.txt

// The final sort -u is useful because Wiktionary occasionally contains duplicate headwords due to historical import quirks, and it produces a deduplicated word list.

/*
[sanmayce@djudjeto11 ~]$ gcc -O3 -march=native -o enwiktionary_wordlist enwiktionary_wordlist.c

[sanmayce@djudjeto11 ~]$ ./enwiktionary_wordlist 
usage: ./enwiktionary_wordlist enwiktionary.xml

[sanmayce@djudjeto11 ~]$ ./enwiktionary_wordlist enwiktionary-20260501-pages-articles.xml> enwiktionary-20260501-pages-articles.xml.words

[sanmayce@djudjeto11 ~]$ head enwiktionary-20260501-pages-articles.xml.words 
dictionary
free
thesaurus
encyclopedia
portmanteau
encyclopaedia
cat
gratis
word
livre

[sanmayce@djudjeto11 ~]$ tail enwiktionary-20260501-pages-articles.xml.words 
muckbang
kuchisabishii
suscepting
earpod
earpods
Powery
stimmable
unfemboyish
free-spiritedly
femboyishness

[sanmayce@djudjeto11 ~]$ wc -l enwiktionary-20260501-pages-articles.xml.words 
1349140 enwiktionary-20260501-pages-articles.xml.words

[sanmayce@djudjeto11 ~]$ sort -u enwiktionary-20260501-pages-articles.xml.words > enwiktionary-20260501-pages-articles.xml.words.unique

[sanmayce@djudjeto11 ~]$ wc -l enwiktionary-20260501-pages-articles.xml.words.unique 
1349140 enwiktionary-20260501-pages-articles.xml.words.unique

[sanmayce@djudjeto11 ~]$ head enwiktionary-20260501-pages-articles.xml.words.unique 
'
-'
0
0-0
000
007
007 knife
007 knives
007s
'00s

[sanmayce@djudjeto11 ~]$ tail enwiktionary-20260501-pages-articles.xml.words.unique 
ZZ plant
ZZ plants
zzxjoanw
zzxjoanws
Zzyzx
zzz
zzzed
zzzing
zzzs
ZZ-ZW system

[sanmayce@djudjeto11 ~]$ ls -l enw*
-rw-r--r-- 1 sanmayce sanmayce 11682653744 Jun 12 09:52 enwiktionary-20260501-pages-articles.xml
-rw-r--r-- 1 sanmayce sanmayce  1584237782 Jun 12 09:52 enwiktionary-20260501-pages-articles.xml.bz2
-rw-r--r-- 1 sanmayce sanmayce    15932663 Jun 12 10:49 enwiktionary-20260501-pages-articles.xml.words
-rw-r--r-- 1 sanmayce sanmayce    15932663 Jun 12 10:50 enwiktionary-20260501-pages-articles.xml.words.unique
-rwxr-xr-x 1 sanmayce sanmayce       13280 Jun 12 10:46 enwiktionary_wordlist
-rw-r--r-- 1 sanmayce sanmayce        3468 Jun 12 09:57 enwiktionary_wordlist.c
[sanmayce@djudjeto11 ~]$ 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define TITLE_MAX 8192

static int extract_tag_content(
    const char *line,
    const char *tag,
    char *out,
    size_t out_size)
{
    char open[64];
    char close[64];

    snprintf(open, sizeof(open), "<%s>", tag);
    snprintf(close, sizeof(close), "</%s>", tag);

    const char *s = strstr(line, open);
    if (!s)
        return 0;

    s += strlen(open);

    const char *e = strstr(s, close);
    if (!e)
        return 0;

    size_t len = (size_t)(e - s);

    if (len >= out_size)
        len = out_size - 1;

    memcpy(out, s, len);
    out[len] = '\0';

    return 1;
}

static int is_word_like(const char *title)
{
    if (!title || !*title)
        return 0;

    for (const unsigned char *p = (const unsigned char *)title; *p; ++p)
    {
        unsigned char c = *p;

        if (isalnum(c))
            continue;

        switch (c)
        {
            case ' ':
            case '-':
            case '\'':
                continue;

            default:
                return 0;
        }
    }

    return 1;
}

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr,
            "usage: %s enwiktionary.xml\n",
            argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "rb");
    if (!fp)
    {
        perror("fopen");
        return 1;
    }

    char line[65536];

    int in_page = 0;
    int ns = -1;
    int redirect = 0;
    int english = 0;

    char title[TITLE_MAX];
    title[0] = 0;

    while (fgets(line, sizeof(line), fp))
    {
        if (strstr(line, "<page>"))
        {
            in_page = 1;
            ns = -1;
            redirect = 0;
            english = 0;
            title[0] = 0;
            continue;
        }

        if (!in_page)
            continue;

        if (strstr(line, "<redirect "))
            redirect = 1;

        if (title[0] == 0)
        {
            extract_tag_content(
                line,
                "title",
                title,
                sizeof(title));
        }

        char nsbuf[64];

        if (extract_tag_content(
                line,
                "ns",
                nsbuf,
                sizeof(nsbuf)))
        {
            ns = atoi(nsbuf);
        }

        if (strstr(line, "==English=="))
            english = 1;

        if (strstr(line, "</page>"))
        {
            if (ns == 0 &&
                !redirect &&
                english &&
                strchr(title, ':') == NULL &&
                is_word_like(title))
            {
                puts(title);
            }

            in_page = 0;
        }
    }

    fclose(fp);
    return 0;
}

